<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use App\Entity\Events;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class EventController extends AbstractController{

    /**
    * @Route("/", name="event_page")
    */
    public function showAction()
    {
        $events = $this->getDoctrine()->getRepository('App:Events')->findAll();
      
        return $this->render('event/index.html.twig', array('events'=>$events));
    }
 
   /**
    * @Route("/create", name="create_page")
    */
   public function createAction(Request $request){

       $event = new Events;

       $form = $this->createFormBuilder($event)
        ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
        ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
        ->add('type', ChoiceType::class, array('choices'=>array('Music'=>'music', 'Theater'=>'theater', 'Movie'=>'movie', 'Sport'=>'sport'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:3%')))
        ->add('date', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:3%')))
        ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
        ->add('img', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
        ->add('page', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
        ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
        ->add('mail', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
        ->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
        ->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:3%')))
         ->getForm();
       $form->handleRequest($request);
       
       if($form->isSubmitted() && $form->isValid()){

           $name = $form['name']->getData();
           $description = $form['description']->getData();
           $type = $form['type']->getData();
           $date = $form['date']->getData();
           $capacity = $form['capacity']->getData();
           $img = $form['img']->getData();
           $page = $form['page']->getData();
           $address = $form['address']->getData();
           $mail = $form['mail']->getData();
           $phone = $form['phone']->getData();
           
 
           $event->setName($name);
           $event->setDescription($description);
           $event->setType($type);
           $event->setDate($date);
           $event->setCapacity($capacity);
           $event->setImg($img);
           $event->setPage($page);
           $event->setAddress($address);
           $event->setMail($mail);
           $event->setPhone($phone);
           $em = $this->getDoctrine()->getManager();
           $em->persist($event);
           $em->flush();
           $this->addFlash(
                   'notice',
                   'Event Added'
                   );
           return $this->redirectToRoute('event_page');
       }

       return $this->render('event/create.html.twig', array('form' => $form->createView()));
   }

   /**
    * @Route("/edit/{id}", name="event_edit")
    */
    public function editAction( $id, Request $request){

        $event = $this->getDoctrine()->getRepository('App:Events')->find($id);

        $event->setName($event->getName());
        $event->setDescription($event->getDescription());
        $event->setType($event->getType());
        $event->setDate($event->getDate());
        $event->setCapacity($event->getCapacity());
        $event->setImg($event->getImg());
        $event->setPage($event->getPage());
        $event->setAddress($event->getAddress());
        $event->setMail($event->getMail());
        $event->setPhone($event->getPhone());

        $form = $this->createFormBuilder($event)
            ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
            ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
            ->add('type', ChoiceType::class, array('choices'=>array('Music'=>'music', 'Theater'=>'theater', 'Movie'=>'movie', 'Sport'=>'sport'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:3%')))
            ->add('date', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:3%')))
            ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
            ->add('img', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
            ->add('page', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
            ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
            ->add('mail', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
            ->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:3%')))
            ->add('save', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:3%')))
            ->getForm();
            $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){ 
            $name = $form['name']->getData();
            $description = $form['description']->getData();
            $type = $form['type']->getData();
            $date = $form['date']->getData();
            $capacity = $form['capacity']->getData();
            $img = $form['img']->getData();
            $page = $form['page']->getData();
            $address = $form['address']->getData();
            $mail = $form['mail']->getData();
            $phone = $form['phone']->getData(); 
            
            $em = $this->getDoctrine()->getManager();

            $event = $em->getRepository('App:Events')->find($id);
            $event->setName($event->getName());
            $event->setDescription($event->getDescription());
            $event->setType($event->getType());
            $event->setDate($event->getDate());
            $event->setCapacity($event->getCapacity());
            $event->setImg($event->getImg());
            $event->setPage($event->getPage());
            $event->setAddress($event->getAddress());
            $event->setMail($event->getMail());
            $event->setPhone($event->getPhone());
               
            $em->flush();
            $this->addFlash(
                'notice',
                'Event Updated'
            );
            return $this->redirectToRoute('event_page');
        }

        return $this->render('event/edit.html.twig', array('event' => $event, 'form' => $form->createView()));
    }

   /**
    * @Route("/details/{id}", name="details_page")
    */
   public function detailsAction($id)
   {
        $event = $this->getDoctrine()->getRepository('App:Events')->find($id);
        return $this->render('event/details.html.twig', array('event' => $event));
   }

   /**
    * @Route("/delete/{id}", name="event_delete")
    */
    public function deleteAction($id){
        $em = $this->getDoctrine()->getManager();
        $todo = $em->getRepository('App:Events')->find($id);
        $em->remove($todo);
        $em->flush();
        $this->addFlash(
           'notice',
           'Event Removed'
        );
    return $this->redirectToRoute('event_page');
    
    }
}
